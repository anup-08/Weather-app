const api = "https://api.openweathermap.org/data/2.5/weather?units=metric";
const apiKey = "YOUR_API_KEY_HERE"; // <--- 👈 Put your key here when testing , It will be available in openWeatherMAp APi

const weatherIcon = document.querySelector("#img");

const input = document.querySelector("#input");


async function checkWeather(value){
    const response = await fetch(`${api}&q=${value}&appid=${apiKey}`);
    const data = await response.json();
    // console.log(data);

    try{
        document.querySelector("#city").innerHTML = data.name;
        document.querySelector("#temp").innerHTML = Math.round(data.main.temp);
        document.querySelector("#windSpeed").innerHTML = data.wind.speed;
        document.querySelector("#humidity").innerHTML = data.main.humidity;
        document.querySelector("#status").innerHTML = data.weather[0].main;

        if(data.weather[0].main == 'Clear'){
            weatherIcon.sec = "images/clear.png"
        }
        else if(data.weather[0].main == 'Clouds'){
            weatherIcon.src = "images/clouds.png";
        }else if(data.weather[0].main == "Drizzle"){
            weatherIcon.src = "images/drizzle.png";
        }else if(data.weather[0].main == "Mist"){
            weatherIcon.src = "images/mist.png";
        }else if(data.weather[0].main == "Rain"){
            weatherIcon.src = "images/rain.png";
        }else if(data.weather[0].main == "Snow"){
            weatherIcon.src = "images/snow.png";
        }
    }
    catch{
        alert("Enter the valid city name");
    }
}

document.querySelector("#button").addEventListener('click' , () =>{

    const value = input.value;
    
    checkWeather(value);
    input.value = "";
})